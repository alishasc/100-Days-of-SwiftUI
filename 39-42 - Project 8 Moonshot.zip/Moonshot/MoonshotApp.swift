//
//  MoonshotApp.swift
//  Moonshot
//
//  Created by Alisha Carrington on 30/06/2025.
//

import SwiftUI

@main
struct MoonshotApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
