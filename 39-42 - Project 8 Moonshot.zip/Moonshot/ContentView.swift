//
//  ContentView.swift
//  Moonshot
//
//  Created by Alisha Carrington on 30/06/2025.
//

import SwiftUI

struct ContentView: View {
    // uses Bundle extension we created
    // use type annotation to make it clear to Swift what astronauts and missions will be
    let astronauts: [String: Astronaut] = Bundle.main.decode("astronauts.json")
    let missions: [Mission] = Bundle.main.decode("missions.json")
    @State private var showingGrid = true  // toggle between grid and list
    
    var body: some View {
        NavigationStack {
            ScrollView {
                if showingGrid {
                    GridLayout(missions: missions, astronauts: astronauts)
                } else {
                    ListLayout(missions: missions, astronauts: astronauts)
                }
            }
            .navigationTitle("Moonshot")
            .background(.darkBackground)
            .preferredColorScheme(.dark)  // set default setting to dark mode - changes nav title white
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    // toggle between list and grid view
                    Button {
                        withAnimation {
                            showingGrid.toggle()
                        }
                    } label: {
                        HStack {
                            Image(systemName: showingGrid ? "list.bullet" : "square.grid.2x2.fill")
                            Text(showingGrid ? "List View" : "Grid View")
                        }
                    }
                }
            }
        }
    }
}

#Preview {
    ContentView()
}

