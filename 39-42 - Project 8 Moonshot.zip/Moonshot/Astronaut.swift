//
//  Astronaut.swift
//  Moonshot
//
//  Created by Alisha Carrington on 30/06/2025.
//

import Foundation

// properties from astronauts json file

struct Astronaut: Codable, Identifiable {
    let id: String
    let name: String
    let description: String
}
