//
//  Mission.swift
//  Moonshot
//
//  Created by Alisha Carrington on 30/06/2025.
//

import Foundation

// properties from astronauts json file

struct Mission: Codable, Identifiable {
    struct CrewRole: Codable {
        let name: String
        let role: String
    }
    
    let id: Int
    let launchDate: Date?  // optional as missing from one data entry
    let crew: [CrewRole]
    let description: String
    
    var displayName: String {
        "Apollo \(id)"
    }
    
    var image: String {
        "apollo\(id)"
    }
    
    // convert optional LaunchDate into a String or return "N/A" for missing dates
    // this will be rendered in a region-appropriate way for the user
    var formattedLaunchDate: String {
        launchDate?.formatted(date: .abbreviated, time: .omitted) ?? "N/A"
    }
}
