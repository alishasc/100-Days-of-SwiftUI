//
//  ScrollViewDemo.swift
//  Moonshot
//
//  Created by Alisha Carrington on 30/06/2025.
//

import SwiftUI

struct ScrollViewDemo: View {
    var body: some View {
        ScrollView {
            LazyVStack(spacing: 10) {
                ForEach(0..<100) {
                    CustomText("Item \($0)")
                        .font(.title)
                }
            }
            // make scrollview fill screen
            .frame(maxWidth: .infinity)
        }
    }
}

struct CustomText: View {
    let text: String
    
    var body: some View {
        Text(text)
    }
    
    init(_ text: String) {
        print("Creating a new CustomText")
        self.text = text
    }
}

#Preview {
    ScrollViewDemo()
}
