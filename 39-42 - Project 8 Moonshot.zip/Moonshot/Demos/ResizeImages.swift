//
//  ResizeImages.swift
//  Moonshot
//
//  Created by Alisha Carrington on 30/06/2025.
//

import SwiftUI

struct ResizeImages: View {
    var body: some View {
        Image(.panda)
            .resizable()
            .scaledToFit()
            // make image fill 80% of the screen
            .containerRelativeFrame(.horizontal) { size, axis in
                size * 0.8
            }
    }
}

#Preview {
    ResizeImages()
}
