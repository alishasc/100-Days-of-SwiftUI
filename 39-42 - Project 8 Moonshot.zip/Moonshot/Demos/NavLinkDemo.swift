//
//  NavLinkDemo.swift
//  Moonshot
//
//  Created by Alisha Carrington on 30/06/2025.
//

import SwiftUI

struct NavLinkDemo: View {
    var body: some View {
        NavigationStack {
            NavigationLink {
                Text("Detail View")
            } label: {
                VStack {
                    Text("This is the label")
                    Text("So is this")
                    Image(systemName: "face.smiling")
                }
                .font(.largeTitle)
            }
            .navigationTitle("SwiftUI")
        }
    }
}

struct NavLinkDemo2: View {
    var body: some View {
        NavigationStack {
            List(0..<100) { row in
                NavigationLink("Row \(row)") {
                    Text("Detail \(row)")
                }
            }
            .navigationTitle("SwiftUI")
        }
    }
}

#Preview {
    NavLinkDemo()
    NavLinkDemo2()
}
